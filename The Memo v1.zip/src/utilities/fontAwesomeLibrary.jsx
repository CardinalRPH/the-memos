import { library } from '@fortawesome/fontawesome-svg-core'
import { faAnglesRight, faArrowLeftLong, faBoxArchive, faCheck, faMagnifyingGlass, faMinus, faNoteSticky, faPlus, faTrash } from '@fortawesome/free-solid-svg-icons'

library.add(faNoteSticky,faBoxArchive, faPlus, faMinus, faAnglesRight, faMagnifyingGlass, faTrash, faCheck, faArrowLeftLong)